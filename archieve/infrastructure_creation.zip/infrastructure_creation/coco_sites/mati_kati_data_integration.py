"""

"""

import os
import sys

repository_name = "RiboSeqAnalysis"
sys.path.append(os.path.abspath(__file__).split(repository_name)[0] + repository_name)
from infrastructure_creation.functions import *
from archieve.common_functions import *


def get_kai_mati_transcripts_cds_ranges(rscript, rdata_path, data_repo_dir, temp_repo_dir, verbose):

    if verbose:
        print(f"{bcolors.HEADER}Transcripts are being fetched.{bcolors.ENDC}")
    output_path = os.path.join(temp_repo_dir, "kai_mati_transcripts.txt")
    transcripts = kai_mati_transcripts_fetch(rscript, rdata_path, output_path)

    if verbose:
        print(f"{bcolors.HEADER}RefSeq GTF file is being parsed.{bcolors.ENDC}")
    gtf_path = download_gtf_refseq(temp_repo_dir)
    gtf = gtf_parser(gtf_path, verbose=verbose)

    if verbose:
        print(f"{bcolors.HEADER}CDS ranges of chosen transcripts are being obtained.{bcolors.ENDC}")
    result_cds = dict()
    result_strand = dict()
    for ind, entry in enumerate(gtf):
        if verbose and (ind % 100 == 0 or ind == len(gtf) - 1):  # Show the progress if 'verbose' is True
            progressBarForTerminal(ind, len(gtf) - 1)
        feature = entry["feature"]
        transcript_id = entry["transcript_id"]
        if feature == "CDS" and transcript_id in transcripts:
            cds_range = [int(entry["exon_number"]), int(entry["start"]), int(entry["end"])]
            result_cds[transcript_id] = result_cds.get(transcript_id, []) + [cds_range]
            if transcript_id not in result_strand :
                result_strand[transcript_id] = entry["strand"]

    if verbose:
        print(f"{bcolors.HEADER}CDS ranges of chosen transcripts are being sorted.{bcolors.ENDC}")
    for r in result_cds:
        result_cds[r] = [(j, k) for i, j, k in sorted(result_cds[r])]

    if verbose:
        print(f"{bcolors.HEADER}Chromosomes are being found.{bcolors.ENDC}")
    mapping = ncbi_accession_to_chromosome(temp_repo_dir)
    ncbi_chromosome = {i: mapping[i] for i in mapping if i in transcripts}
    ncbi_chromosome, result_cds = sync_dictionaries(ncbi_chromosome, result_cds)
    ncbi_chromosome, result_strand = sync_dictionaries(ncbi_chromosome, result_strand)

    output = dict()
    for tid in list(ncbi_chromosome.keys()):
        output[tid] = {"cds": result_cds[tid], "strand": result_strand[tid], "contig": ncbi_chromosome[tid]}

    # Write down the output dictionary and list as Joblib object for convenience in later uses.
    #if verbose:
    #    print(f"{bcolors.HEADER}Results are written to disk: {data_repo_dir}{bcolors.ENDC}")
    #os.chdir(data_repo_dir)  # Since all outputs will be written in the same directory.
    #joblib.dump((result_cds, result_strand), f"mati_kai_refseq_transcripts_cds_ranges.joblib")
    #if verbose:
    #    print("Done: mati_kai_refseq_transcripts_cds_ranges.joblib")

    return output


def ncbi_transcripts_allocate_ensembl_genes(temp_repo_dir, kai_mati_transcripts, tolerance= 1000, verbose=True):

    if verbose:
        print(f"{bcolors.HEADER}Genes are being fetched from MANE project.{bcolors.ENDC}")
    ero = ensembl_release_object_creator()  # Create a new ensembl release object of pyensembl library.
    # Determine which genes we are interested in so that assign footprints to these genes only.
    gene_list = list(mane_gene_maps_with_defined_protein(ero, temp_repo_dir).keys())

    transcript_list = list(kai_mati_transcripts.keys())

    output = dict()
    t = set()
    ll = list()
    for ind, gene_id in enumerate(gene_list):
        gene_object = ero.gene_by_id(gene_id)
        for transcript_id in transcript_list:
            transcript_subdict = kmt[transcript_id]
            if gene_object.contig == transcript_subdict["contig"]:

                cdss = [i for k in transcript_subdict["cds"] for i in k]
                assert gene_object.start <= gene_object.end

                if gene_object.end >= min(cdss) >= gene_object.start and \
                        gene_object.start <= max(cdss) <= gene_object.end:
                    output[gene_id] = output.get(gene_id, []) + [transcript_id]
                    t.add(transcript_id)

    gtf_path = download_gtf_refseq(temp_repo_dir)
    gtf = gtf_parser(gtf_path, verbose=verbose)

    oo = {e_gtf["transcript_id"]: e_gtf["gene"] for e_gtf in gtf if
          "transcript_id" in e_gtf and "db_xref" in e_gtf and "GeneID:" in e_gtf["db_xref"]}
    oo2 = {e_gtf["transcript_id"]: e_gtf["db_xref"].split("GeneID:")[1] for e_gtf in gtf if
           "transcript_id" in e_gtf and "db_xref" in e_gtf and "GeneID:" in e_gtf["db_xref"]}



    mapp = gene_refseq_to_ensembl(temp_repo_dir, "NtoE")

    d = dict()

    with open("/Users/kemalinecik/Desktop/as.txt") as input_handle:
        map_raw = [i.strip().split('\t') for i in input_handle.readlines() if not i.startswith('#')]
        for m in map_raw:
            d[m[0]] = m[1]

    a = list()
    for i in transcripts:
        try:
            d[i.split(".")[0]]
        except (AssertionError, KeyError):
            a.append(i)


    a = list()
    for i in transcript_list:
        try:
            assert dd[oo2[i]] in gene_list

        except (AssertionError, KeyError):
            a.append(i)

    a2 = list()
    for i in a:
        try:
            d[oo[i]]
        except (KeyError, ValueError):
            a2.append(i)

    temp_repo_dir="/Users/kemalinecik/Desktop"
    um = uniprot_to_db_mapping_multiple(temp_repo_dir, "GeneID", "Ensembl")
    om = dict()
    for i in um:
        um_e = um[i].get("Ensembl")
        um_g = um[i].get("GeneID")
        if um_e and um_g:
            om.update({j:i for i in um_e for j in um_g})



    a3 = list()
    for i in a2:
        try:
            cdss = [m for k in kai_mati_transcripts[i]["cds"] for m in k]
            if kai_mati_transcripts[i]["contig"]:
                print(ero.gene_ids_at_locus(kai_mati_transcripts[i]["contig"], min(cdss), max(cdss), kai_mati_transcripts[i]["strand"]))
        except (KeyError, ValueError):
            a3.append(i)


    amk=[j for i in output.values() for j in i]
    a3 = [k for k in a2 if k not in amk]

# Call the main function
kmt = get_kai_mati_transcripts_cds_ranges(rscript, rdata_path, data_repo_dir, temp_repo_dir, verbose=True)








if __name__ == '__main__':
    rscript_path = os.path.join(os.path.dirname(__file__), "mati_kai_transcripts.R")
    rdata =  sys.argv[1]  #
    output_dir = sys.argv[2]  # Absolute path of output directory
    temp_dir = sys.argv[3]  # Absolute path of temp directory
    data_repo_dir = os.path.join(output_dir, "protein_structure")
    temp_repo_dir = os.path.join(temp_dir, "protein_structure")

# todo: length check: "range_sum(result["NM_001136203.1"]) / 3 - 1" çünkü stop codon
# todo: makaleye göre gerekli olanları al
# todo: functionları yaz buraya kontrol et diğer taraftan. oriantasyona göre şeyap!
# todo: mane genleri okut, genome_range'lerini uygun şekilde yerleştir
# todo: hesaplanılan rakamları genome'a yerleştir np.nan for introns
# todo: sonuçları ve relavant her şeyi kaydet joblib'e
# todo: genome_infrastructure'a bunları ekle



# End of the script
